package com.device.identity.userservice;

import com.alibaba.fastjson.JSONObject;
import com.device.identity.common.ResponseWrap;
import com.device.identity.common.ServerAuthData;
import com.device.identity.util.JdOpenApiUtil;

/**
 * 调用京东云服务测试类
 */
public class JdOpenApiUtilTest {
	public static void main(String[] args) {
		String deviceAuthData = "AAAAAAAAAA";

		ResponseWrap<ServerAuthData> responseWrap = JdOpenApiUtil.getAuthResult(deviceAuthData);
		System.out.println(JSONObject.toJSONString(responseWrap));
	}
}

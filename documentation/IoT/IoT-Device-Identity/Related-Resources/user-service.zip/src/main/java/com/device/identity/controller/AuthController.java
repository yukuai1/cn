package com.device.identity.controller;

import com.device.identity.common.ResponseWrap;
import com.device.identity.common.ServerAuthData;
import com.device.identity.util.JdOpenApiUtil;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

/**
 * @author 京东IOT
 * @date 2022/1/25 14:48
 */
@RestController
@RequestMapping("/tid")
public class AuthController {

    /**
     * 获取设备认证结果
     * @param params
     * @return
     */
    @PostMapping("/authenticate")
    public ResponseWrap<ServerAuthData> getAuth(@RequestBody Map<String, String> params) {
        String deviceAuthData = params.get("hexString");

        //请求认证服务器，获取结果
        return JdOpenApiUtil.getAuthResult(deviceAuthData);
    }
}

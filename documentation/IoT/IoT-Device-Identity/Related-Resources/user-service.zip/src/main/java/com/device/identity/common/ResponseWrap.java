package com.device.identity.common;

import java.io.Serializable;

/**
 * 用户服务器的返回结构（可根据自身情况修改）
 * @author 京东IOT
 * @date 2022/1/25 14:50
 */
public class ResponseWrap<T> implements Serializable {

    private int code;
    private String errorMsg;
    private T data;

    public ResponseWrap() {
        this.code = 200;
    }

    public ResponseWrap(int code, String errorMsg) {
        this.code = code;
        this.errorMsg = errorMsg;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getErrorMsg() {
        return errorMsg;
    }

    public void setErrorMsg(String errorMsg) {
        this.errorMsg = errorMsg;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }
}

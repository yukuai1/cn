package com.device.identity.common;

import java.io.Serializable;

/**
 * 认证返回类
 * @author 京东IOT
 * @date 2022/2/9 15:19
 */
public class ServerAuthData implements Serializable {
    /**
     * 默认的序列化 id.
     */
    private static final long serialVersionUID = -9116754236141765795L;

    /**
     * 服务端认证信息.
     */
    private String serverAuthCode;

    /**
     * token明文.
     */
    private String tokenPlaintext;

    public String getServerAuthCode() {
        return serverAuthCode;
    }

    public void setServerAuthCode(String serverAuthCode) {
        this.serverAuthCode = serverAuthCode;
    }

    public String getTokenPlaintext() {
        return tokenPlaintext;
    }

    public void setTokenPlaintext(String tokenPlaintext) {
        this.tokenPlaintext = tokenPlaintext;
    }
}

package com.device.identity.common;

import java.io.Serializable;

/**
 * 认证参数类
 * @author 京东IOT
 * @date 2022/1/25 14:58
 */
public class AuthData implements Serializable {

    private static final long serialVersionUID = -590449669815734360L;

    /**
     * 设备认证字符串.
     */
    String clientAuthCode;

    /**
     * 版本.
     */
    String version;

    /**
     * 请求id.
     */
    String requestId;

    /**
     * 时间戳.
     */
    Long timeStamp;

    public String getClientAuthCode() {
        return clientAuthCode;
    }

    public void setClientAuthCode(String clientAuthCode) {
        this.clientAuthCode = clientAuthCode;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public Long getTimeStamp() {
        return timeStamp;
    }

    public void setTimeStamp(Long timeStamp) {
        this.timeStamp = timeStamp;
    }
}
